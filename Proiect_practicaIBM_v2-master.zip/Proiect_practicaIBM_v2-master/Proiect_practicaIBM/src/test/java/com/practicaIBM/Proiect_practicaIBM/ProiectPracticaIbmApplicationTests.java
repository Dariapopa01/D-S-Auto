package com.practicaIBM.Proiect_practicaIBM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProiectPracticaIbmApplicationTests {

	@Test
	void contextLoads() {
	}

}
