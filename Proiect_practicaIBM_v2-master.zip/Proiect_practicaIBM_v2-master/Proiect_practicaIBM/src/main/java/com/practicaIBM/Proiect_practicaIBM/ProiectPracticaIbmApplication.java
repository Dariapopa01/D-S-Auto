package com.practicaIBM.Proiect_practicaIBM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProiectPracticaIbmApplication {

	public static void main(String[] args) {

		SpringApplication.run(ProiectPracticaIbmApplication.class, args);
	}

}
