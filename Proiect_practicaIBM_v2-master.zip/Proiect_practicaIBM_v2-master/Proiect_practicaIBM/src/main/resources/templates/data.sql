insert into t_cars ( regnumber, marca, model, power, type, an, consum) values('BV076764','BMW','seria7',5500,'Sedan',2011,13.1);
insert into t_cars ( regnumber, marca, model, power, type, an, consum) values('BV076764','BMW','seria7',5500,'Sedan',2011,13.1);
