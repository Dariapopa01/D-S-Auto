create table t_cars(

    id integer,
    regnumber varchar(50),
    marca varchar(50),
    model varchar(50),
    power integer,
    type varchar(50),
    an integer,
    consum integer,
    primary key(id)
    );